# Установка аутентификации

## 1. Установить зависимости:
```bash
npm install bcryptjs jsonwebtoken @types/bcryptjs @types/jsonwebtoken
```

## 2. Добавить в основной файл сервера:
```typescript
import authRoutes from './auth';

// Добавить роутер аутентификации
app.use('/api/auth', authRoutes);
```

## 3. Настроить переменные окружения:
```bash
JWT_SECRET=your-secret-key-here
JWT_REFRESH_SECRET=your-refresh-secret-key-here
```

## 4. Перезапустить сервер
